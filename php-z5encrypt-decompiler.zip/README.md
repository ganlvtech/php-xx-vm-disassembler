# PHP Z5Encrypt Disassembler

这个虚拟机挺复杂的，很多种反调试手段。不过手动单步运行分析，然后手动翻译是能成功的。

时间不充裕，代码是半成品，有些变量直接写在代码中了，不打算继续维护了。原本想尝试做反编译的，目前只做了反汇编。

    PHP Z5Encrypt Disassembler
    Copyright (C) 2019  Ganlv

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.