<?php 

function main() {
	phpinfo();
}

main();
